package edu.skku.cs.week5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.TextView;

public class NothingActivity extends AppCompatActivity {

    static int hour2 = 0;
    static int min2 = 0;
    static String desc2 = "desc";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nothing);

        Intent intent = getIntent();
        int hour = intent.getIntExtra(MainActivity.EXT_HOUR, 0);
        hour2 = hour;
        int min = intent.getIntExtra(MainActivity.EXT_MIN, 0);
        min2 = min;
        String desc = intent.getStringExtra(MainActivity.EXT_DESC);
        desc2 = desc;

        TextView textView = (TextView) findViewById(R.id.edittext_show);
        if (min == 0 && hour == 0) {
            textView.setText("Do you want to set alarm on time 00:00 with description '" + desc + "'?");
        }
        else if (min == 0 && hour != 0) {
            textView.setText("Do you want to set alarm on time " + hour + ":00 with description '" + desc + "'?");
        }
        else if (min != 0 && hour == 0) {
            textView.setText("Do you want to set alarm on time 00:" + min + " with description '" + desc + "'?");
        }
        else {
            textView.setText("Do you want to set alarm on time " + hour + ":" + min +
                    " with description '" + desc + "'?");
        }
    }

    public void setAlarm(View v) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_MESSAGE, desc2)
                .putExtra(AlarmClock.EXTRA_HOUR, hour2)
                .putExtra(AlarmClock.EXTRA_MINUTES, min2);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void goFirst(View v) {
        Intent intent = new Intent(NothingActivity.this, MainActivity.class);
        startActivity(intent);
    }
}