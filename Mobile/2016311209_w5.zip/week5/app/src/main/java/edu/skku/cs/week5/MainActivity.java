package edu.skku.cs.week5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public static final String EXT_HOUR = "Hour";
    public static final String EXT_MIN = "Min";
    public static final String EXT_DESC = "Desc";
    public void startNewActivity(View v) {
        EditText editText = findViewById(R.id.edittext_time);
        EditText editText2 = findViewById(R.id.edittext_desc);

        String hour2 = editText.getText().toString().split(":")[0];
        int hour = Integer.parseInt(hour2);
        String min2 = editText.getText().toString().split(":")[1];
        int min = Integer.parseInt(min2);
        String desc = editText2.getText().toString();

        Intent intent = new Intent(MainActivity.this, NothingActivity.class);
        intent.putExtra(EXT_HOUR, hour);
        intent.putExtra(EXT_MIN, min);
        intent.putExtra(EXT_DESC, desc);
        startActivity(intent);
    }
}