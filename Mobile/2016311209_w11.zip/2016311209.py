#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 13:33:24 2022

@author: hsherlcok
"""

from flask import Flask
from flask import request
from flask import jsonify

import random
import math
import time

# This line is for solving flask's CORS error
# You need 'pip install flask_cors' to use flask_cors
#from flask_cors import CORS
from werkzeug.serving import WSGIRequestHandler
import json
WSGIRequestHandler.protocol_version = "HTTP/1.1"

app = Flask(__name__)

# This line is for solving flask's CORS error
#CORS(app)

global pi

@app.route("/monte-carlo/pi", methods=['GET'])
def get_pi1():
    num_imsi = request.args.get('n')
    num = int(num_imsi)

    global pi
    ret = {}
    total = 0

    start = time.time()

    for i in range(1, num + 1):
        x = random.random()
        y = random.random()
        if math.sqrt(x * x + y * y) <= 1:
            total = total + 1

    pi = 4 * total / num

    end = time.time()

    ret["elapse time"] = end - start
    ret["pi"] = pi

    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify(ret), 200

@app.route("/get/pi", methods=['GET'])
def get_pi2():
    global pi
    ret = {}

    ret["pi"] = pi

    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify(ret)

@app.route("/update/pi", methods=['POST'])
def update_pi():
    content = request.get_json(silent=True)

    global pi

    num = content["pi"]
    pi = num

    return jsonify(success=True)
    
if __name__ == "__main__":
    app.run(host='localhost', port=8888)