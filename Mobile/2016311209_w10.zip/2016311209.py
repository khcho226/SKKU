import json

def lambda_handler(event, context):
    params = event ['queryStringParameters']
    
    t = params['t']
    
    obj = {
        'Title' : 'Spider-Man: No Way Home',
        'Year' : '2021',
        'Released' : '17 Dec 2021',
        'Runtime' : '148 min',
        'Genre' : 'Action, Adventure, Fantasy',
        'imdbRating' : '8.5',
        'Metascore' : '71'
    }
    
    if t == 'spider man no way home':
        return {
            'statusCode': 200,
            'body': json.dumps(obj)
        }