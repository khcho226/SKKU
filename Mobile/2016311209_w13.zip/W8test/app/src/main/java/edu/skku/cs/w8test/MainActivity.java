package edu.skku.cs.w8test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    Button button;
    TextView textView2;
    EditText editText;

    static Object weather_descriptions = "";
    static Object temperature = "";
    static Object humidity = "";
    static Object name = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView2 = findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editTextTextPersonName);
        button = findViewById(R.id.button);

        button.setOnClickListener(view -> {
            OkHttpClient client = new OkHttpClient();
            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://c52rx458ga.execute-api.ap-northeast-2.amazonaws.com/dev/access").newBuilder();
            urlBuilder.addQueryParameter("name", editText.getText().toString());
            String url = urlBuilder.build().toString();
            Request req = new Request.Builder().url(url).build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    final String myResponse = response.body().string();
                    String[] res = myResponse.split("\"");

                    OkHttpClient client2 = new OkHttpClient();
                    HttpUrl.Builder urlBuilder2 = HttpUrl.parse("http://api.weatherstack.com/current").newBuilder();
                    urlBuilder2.addQueryParameter("access_key", "c7a11f0bd97edcd0273fbd64d6242336");
                    urlBuilder2.addQueryParameter("query", res[1]);
                    String url2 = urlBuilder2.build().toString();
                    Request req2 = new Request.Builder().url(url2).build();

                    client2.newCall(req2).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NonNull Call call, @NonNull IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                            final String myResponse2 = response.body().string();

                            try {
                                JSONObject json = new JSONObject(myResponse2);

                                JSONObject json_current = json.getJSONObject("current");
                                weather_descriptions = json_current.get("weather_descriptions");
                                temperature = json_current.get("temperature");
                                humidity = json_current.get("humidity");

                                JSONObject json_location = json.getJSONObject("location");
                                name = json_location.get("name");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            String des[] = weather_descriptions.toString().split("\"");

                            MainActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView2.setText("Weather_descriptions : " + des[1]
                                        + "\nTemperature : " + temperature
                                        + "\nHumidity : " + humidity
                                        + "\nName : " + name);
                                }
                            });
                        }
                    });
                }
            });
        });
    }
}