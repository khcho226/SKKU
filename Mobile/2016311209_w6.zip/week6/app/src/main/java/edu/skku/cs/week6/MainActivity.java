package edu.skku.cs.week6;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    CustomHandler handler = new CustomHandler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomThread runnable = new CustomThread();
        textView = findViewById(R.id.textView);
        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(view -> {
            new Thread(runnable).start();
        });
    }

    class CustomThread implements Runnable {
        double x, y, result, number, count = 0;
        int j = 999999;

        @Override
        public void run() {
            for (int i = 0; i < 100000000; i++) {
                x = Math.random();
                y = Math.random();
                result = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));

                if (result <= 1) {
                    count = count + 1;
                }

                if (i == j) {
                    number = 4 * count / j;
                    j = j + 1000000;

                    Bundle bundle = new Bundle();
                    bundle.putDouble("value", number);
                    Message msg = new Message();
                    msg.setData(bundle);
                    handler.sendMessage(msg);
                }
            }
            postToast("Finish Estimate");
        }
    }

    class CustomHandler extends Handler {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            Bundle bundle = msg.getData();
            String value = String.valueOf(bundle.getDouble("value"));
            textView.setText(value);
        }
    }

    public void postToast(final String message) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}