package edu.skku.cs.pa2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;

import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MazeActivity extends AppCompatActivity {
    TextView textView;
    ImageView imageView;

    private GridView gridView;
    private MazeAdapter mazeAdapter;
    private ArrayList<MazeClass> items;

    private int turn = 0;
    private int row = 0;
    private int col = 0;
    private int curRow = 0;
    private int curCol = 0;
    private int counter = 0;

    private int[] arr_up = {8, 9 ,10, 11, 12, 13, 14, 15};
    private int[] arr_down = {2, 3, 6, 7, 10, 11, 14, 15};
    private int[] arr_left = {4, 5, 6, 7, 12, 13, 14, 15};
    private int[] arr_right = {1, 3, 5, 7, 9, 11, 13, 15};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maze);

        textView = findViewById(R.id.textView4);
        imageView = findViewById(R.id.imageView);
        gridView = findViewById(R.id.gridView);

        Intent intent = getIntent();
        String mazename = intent.getStringExtra(SelectionAdapter.EXT_MAZENAME);
        int mazesize = intent.getIntExtra(SelectionAdapter.EXT_MAZESIZE, 0);

        Button button_up = findViewById(R.id.button_up);
        Button button_down = findViewById(R.id.button_down);
        Button button_left = findViewById(R.id.button_left);
        Button button_right = findViewById(R.id.button_right);
        Button button_hint = findViewById(R.id.button_hint);

        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("http://115.145.175.57:10099/maze/map").newBuilder();
        urlBuilder.addQueryParameter("name", mazename);
        String url = urlBuilder.build().toString();
        Request req = new Request.Builder().url(url).build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();
                String[] line = myResponse.split(" ");

                int[][] array = new int[mazesize][mazesize];
                int[][] array_bfs = new int[mazesize][mazesize];
                int[][] array_img = new int[mazesize][mazesize];

                array_img[row][col] = 1;
                array_img[mazesize - 1][mazesize - 1] = 6;

                for (int i = 0; i < mazesize; i++) {
                    for (int j = 0; j < mazesize; j++) {
                        if (j == 0) {
                            int input = Integer.valueOf(line[mazesize * i + j].split("n")[1]).intValue();
                            array[i][j] = input;
                            array_bfs[i][j] = input;
                        }

                        else {
                            array[i][j] = Integer.valueOf(line[mazesize * i + j]).intValue();
                            array_bfs[i][j] = Integer.valueOf(line[mazesize * i + j]).intValue();
                        }
                    }
                }

                gridView.setNumColumns(mazesize);
                gridView.setSelector(new StateListDrawable());
                items = new ArrayList<>();

                for (int i = 0; i < mazesize; i++) {
                    for (int j = 0; j < mazesize; j++) {
                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                    }
                }

                MazeActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                        gridView.setAdapter(mazeAdapter);
                        textView.setText("Turn : " + Integer.toString(turn));

                        button_up.setOnClickListener(view -> {
                            if (!Arrays.stream(arr_up).anyMatch(k -> k == array[row][col])) {
                                array_img[row][col] = 0;
                                array_img[row - 1][col] = 1;

                                items = new ArrayList<>();

                                for (int i = 0; i < mazesize; i++) {
                                    for (int j = 0; j < mazesize; j++) {
                                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                                    }
                                }

                                mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                                gridView.setAdapter(mazeAdapter);

                                row = row - 1;
                                turn = turn + 1;

                                textView.setText("Turn : " + Integer.toString(turn));

                                if (row == mazesize - 1 && col == mazesize - 1) {
                                    Toast.makeText(MazeActivity.this, "Finish!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        button_down.setOnClickListener(view -> {
                            if (!Arrays.stream(arr_down).anyMatch(k -> k == array[row][col])) {
                                array_img[row][col] = 0;
                                array_img[row + 1][col] = 2;

                                items = new ArrayList<>();

                                for (int i = 0; i < mazesize; i++) {
                                    for (int j = 0; j < mazesize; j++) {
                                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                                    }
                                }

                                mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                                gridView.setAdapter(mazeAdapter);

                                row = row + 1;
                                turn = turn + 1;

                                textView.setText("Turn : " + Integer.toString(turn));

                                if (row == mazesize - 1 && col == mazesize - 1) {
                                    Toast.makeText(MazeActivity.this, "Finish!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        button_left.setOnClickListener(view -> {
                            if (!Arrays.stream(arr_left).anyMatch(k -> k == array[row][col])) {
                                array_img[row][col] = 0;
                                array_img[row][col - 1] = 3;

                                items = new ArrayList<>();

                                for (int i = 0; i < mazesize; i++) {
                                    for (int j = 0; j < mazesize; j++) {
                                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                                    }
                                }

                                mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                                gridView.setAdapter(mazeAdapter);

                                col = col - 1;
                                turn = turn + 1;

                                textView.setText("Turn : " + Integer.toString(turn));

                                if (row == mazesize - 1 && col == mazesize - 1) {
                                    Toast.makeText(MazeActivity.this, "Finish!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        button_right.setOnClickListener(view -> {
                            if (!Arrays.stream(arr_right).anyMatch(k -> k == array[row][col])) {
                                array_img[row][col] = 0;
                                array_img[row][col + 1] = 4;

                                items = new ArrayList<>();

                                for (int i = 0; i < mazesize; i++) {
                                    for (int j = 0; j < mazesize; j++) {
                                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                                    }
                                }

                                mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                                gridView.setAdapter(mazeAdapter);

                                col = col + 1;
                                turn = turn + 1;

                                textView.setText("Turn : " + Integer.toString(turn));

                                if (row == mazesize - 1 && col == mazesize - 1) {
                                    Toast.makeText(MazeActivity.this, "Finish!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        button_hint.setOnClickListener(view -> {
                            if (counter == 0) {
                                curRow = row;
                                curCol = col;
                                String curRoad = "";
                                String realRoad = "";

                                LinkedList<Path> queue = new LinkedList<>();
                                queue.add(new Path(curRow, curCol, curRoad));

                                while (!queue.isEmpty()) {
                                    Path path = (Path) queue.poll();

                                    curRow = path.path_row;
                                    curCol = path.path_col;
                                    curRoad = path.path_road;
                                    realRoad = curRoad;

                                    if (curRow == mazesize - 1 && curCol == mazesize - 1) {
                                        break;
                                    }

                                    if (curRow - 1 >= 0 && array_bfs[curRow - 1][curCol] != 0 && !Arrays.stream(arr_up).anyMatch(k -> k == array_bfs[curRow][curCol])) {
                                        queue.add(new Path(curRow - 1, curCol, curRoad));
                                    }

                                    if (curRow + 1 < mazesize && array_bfs[curRow + 1][curCol] != 0 && !Arrays.stream(arr_down).anyMatch(k -> k == array_bfs[curRow][curCol])) {
                                        queue.add(new Path(curRow + 1, curCol, curRoad));
                                    }

                                    if (curCol - 1 >= 0 && array_bfs[curRow][curCol - 1] != 0 && !Arrays.stream(arr_left).anyMatch(k -> k == array_bfs[curRow][curCol])) {
                                        queue.add(new Path(curRow, curCol - 1, curRoad));
                                    }

                                    if (curCol + 1 < mazesize && array_bfs[curRow][curCol + 1] != 0 && !Arrays.stream(arr_right).anyMatch(k -> k == array_bfs[curRow][curCol])) {
                                        queue.add(new Path(curRow, curCol + 1, curRoad));
                                    }

                                    array_bfs[curRow][curCol] = 0;
                                }

                                queue.clear();
                                counter = 1;

                                if (array_img[Integer.parseInt(realRoad.substring(6, 7))][Integer.parseInt(realRoad.substring(8, 9))] != 6) {
                                    array_img[Integer.parseInt(realRoad.substring(6, 7))][Integer.parseInt(realRoad.substring(8, 9))] = 5;
                                }

                                items = new ArrayList<>();

                                for (int i = 0; i < mazesize; i++) {
                                    for (int j = 0; j < mazesize; j++) {
                                        items.add(new MazeClass(array[i][j], array_img[i][j], mazesize));
                                    }
                                }

                                mazeAdapter = new MazeAdapter(items, MazeActivity.this);
                                gridView.setAdapter(mazeAdapter);
                            }
                        });
                    }
                });
            }
        });
    }

    public class Path {
        int path_row, path_col;
        String path_road;

        public Path(int path_row, int path_col, String oldRoad) {
            this.path_row = path_row;
            this.path_col = path_col;

            if ("".equals(oldRoad)) {
                this.path_road = "(" + path_row + "," + path_col + ")";
            }

            else {
                this.path_road = oldRoad + "(" + path_row + "," + path_col + ")";
            }
        }
    }
}