package edu.skku.cs.pa2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;

public class MazeAdapter extends BaseAdapter {
    private ArrayList<MazeClass> items;
    private Context mContext;

    MazeAdapter (ArrayList<MazeClass> items, Context mContext) {
        this.items = items;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        int sum = items.get(i).num;
        int image = items.get(i).image_num;
        int mazesize = items.get(i).size_num;
        int px = mContext.getResources().getDimensionPixelSize(R.dimen.gridViewSize);

        if (view == null) {
            LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.maze_layout, viewGroup, false);
            view.setLayoutParams(new ViewGroup.LayoutParams(Math.floorDiv(px, mazesize), Math.floorDiv(px, mazesize)));
        }

        ImageView imageView = view.findViewById(R.id.imageView2);
        ImageView character = view.findViewById(R.id.imageView3);
        ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) imageView.getLayoutParams();

        if (sum - 8 >= 0) {
            params.topMargin = (px / 350) * 3;
            sum = sum - 8;
        }

        if (sum - 4 >= 0) {
            params.leftMargin = (px / 350) * 3;
            sum = sum - 4;
        }

        if (sum - 2 >= 0) {
            params.bottomMargin = (px / 350) * 3;
            sum = sum - 2;
        }

        if (sum - 1 >= 0) {
            params.rightMargin = (px / 350) * 3;
        }

        imageView.setLayoutParams(params);

        if (image == 1) {
            character.setImageResource(R.drawable.user_up);
        }

        if (image == 2) {
            character.setImageResource(R.drawable.user_down);
        }

        if (image == 3) {
            character.setImageResource(R.drawable.user_left);
        }

        if (image == 4) {
            character.setImageResource(R.drawable.user_right);
        }

        if (image == 5) {
            character.setImageResource(R.drawable.hint);
        }

        if (image == 6) {
            character.setImageResource(R.drawable.goal);
        }

        return view;
    }
}