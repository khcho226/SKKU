package edu.skku.cs.pa2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SelectionActivity extends AppCompatActivity {
    TextView textView;
    ArrayList<String> name = new ArrayList<>();
    ArrayList<Integer> size = new ArrayList<>();

    private ListView listView;
    private SelectionAdapter selectionAdapter;
    private ArrayList<SelectionClass> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        textView = findViewById(R.id.textView2);

        Intent intent = getIntent();
        String username = intent.getStringExtra(MainActivity.EXT_USERNAME);
        textView.setText(username);

        OkHttpClient client = new OkHttpClient();
        Request req = new Request.Builder().url("http://115.145.175.57:10099/maps").build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();

                try {
                    JSONArray jsonArray = new JSONArray(myResponse);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String jsonName = jsonObject.getString("name");
                        Integer jsonSize = jsonObject.getInt("size");
                        name.add(jsonName);
                        size.add(jsonSize);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                SelectionActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        listView = findViewById(R.id.listView);
                        items = new ArrayList<>();

                        for (int i = 0; i < name.size(); i++) {
                            items.add(new SelectionClass(name.get(i), size.get(i)));
                        }

                        selectionAdapter = new SelectionAdapter(items, SelectionActivity.this);
                        listView.setAdapter(selectionAdapter);
                    }
                });
            }
        });
    }
}