package edu.skku.cs.pa2;

public class SelectionClass {
    public String name_sel;
    public int size_sel;

    public SelectionClass(String name_sel, int size_sel) {
        this.name_sel = name_sel;
        this.size_sel = size_sel;
    }
}