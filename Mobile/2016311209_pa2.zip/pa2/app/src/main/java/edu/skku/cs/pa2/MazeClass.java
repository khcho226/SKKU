package edu.skku.cs.pa2;

public class MazeClass {
    public int num;
    public int image_num;
    public int size_num;

    public MazeClass(int num, int image_num, int size_num) {
        this.num = num;
        this.image_num = image_num;
        this.size_num = size_num;
    }
}
