package edu.skku.cs.pa2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class SelectionAdapter extends BaseAdapter {
    private ArrayList<SelectionClass> items;
    private Context mContext;

    public static final String EXT_MAZENAME = "MAZENAME";
    public static final String EXT_MAZESIZE = "MAZESIZE";

    SelectionAdapter (ArrayList<SelectionClass> items, Context mContext) {
        this.items = items;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.selection_layout, viewGroup, false);
        }

        TextView textView1 = view.findViewById(R.id.textView5);
        TextView textView2 = view.findViewById(R.id.textView6);
        Button button = view.findViewById(R.id.button2);

        textView1.setText(items.get(i).name_sel);
        textView2.setText(Integer.toString(items.get(i).size_sel));

        button.setOnClickListener(view_sel -> {
            Intent intent = new Intent(view_sel.getContext(), MazeActivity.class);
            intent.putExtra(EXT_MAZENAME, items.get(i).name_sel);
            intent.putExtra(EXT_MAZESIZE, items.get(i).size_sel);
            mContext.startActivity(intent);
        });

        return view;
    }
}
