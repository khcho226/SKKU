package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listview;
    private MyListViewAdaptor listViewAdapter;
    private MyListViewAdaptor listViewAdapter2;
    private MyListViewAdaptor listViewAdapter3;
    private ArrayList<Restaurant> items;
    private ArrayList<Restaurant> items2;
    private ArrayList<Restaurant> items3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.button_sub);
        LinearLayout container = findViewById(R.id.container);

        btn.setOnClickListener(view -> {
            LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            inflator.inflate(R.layout.sub_layout, container, true);

            ImageView img1 = findViewById(R.id.sub_image1);
            ImageView img2 = findViewById(R.id.sub_image2);

            img1.setImageResource(R.drawable.bbq);
            img2.setImageResource(R.drawable.bhc);
        });

        listview = findViewById(R.id.listview);

        items = new ArrayList<>();
        items.add(new Restaurant("도미노 피자", R.drawable.domino));
        items.add(new Restaurant("피자헛", R.drawable.pizzahut));
        items.add(new Restaurant("피자나라 치킨공주", R.drawable.pizzanarachickengongju));
        listViewAdapter = new MyListViewAdaptor(getApplicationContext(), items);

        items2 = new ArrayList<>();
        items2.add(new Restaurant("맥도날드", R.drawable.mcdonalds));
        items2.add(new Restaurant("롯데리아", R.drawable.lotteria));
        items2.add(new Restaurant("버거킹", R.drawable.burgerking));
        items2.add(new Restaurant("맘스터치", R.drawable.momstouch));
        listViewAdapter2 = new MyListViewAdaptor(getApplicationContext(), items2);

        items3 = new ArrayList<>();
        items3.add(new Restaurant("bbq", R.drawable.bbq));
        items3.add(new Restaurant("bhc", R.drawable.bhc));
        items3.add(new Restaurant("피자나라 치킨공주", R.drawable.pizzanarachickengongju));
        items3.add(new Restaurant("굽네치킨", R.drawable.goobne));
        listViewAdapter3 = new MyListViewAdaptor(getApplicationContext(), items3);

        listview.setAdapter(listViewAdapter);

        Button btn1 = (Button)findViewById(R.id.button);
        Button btn2 = (Button)findViewById(R.id.button2);
        Button btn3 = (Button)findViewById(R.id.button3);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listview.setAdapter(listViewAdapter);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listview.setAdapter(listViewAdapter2);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listview.setAdapter(listViewAdapter3);
            }
        });
    }
}