package com.example.myapplication;

public class Restaurant {
    public String name;
    public int imgId;

    public Restaurant(String name, int imgId) {
        this.name = name;
        this.imgId = imgId;
    }
}
