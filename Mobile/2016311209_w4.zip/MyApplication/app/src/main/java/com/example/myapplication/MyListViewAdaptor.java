package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListViewAdaptor extends BaseAdapter {
    private Context mContext;
    private ArrayList<Restaurant> items;

    public MyListViewAdaptor(Context mContext, ArrayList<Restaurant> items) {
        this.mContext = mContext;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater inflator = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflator.inflate(R.layout.listview_item, viewGroup, false);
        }

        ImageView img = view.findViewById(R.id.item_image);
        TextView text = view.findViewById(R.id.item_text);

        img.setImageResource(items.get(i).imgId);
        text.setText(items.get(i).name);

        return view;
    }
}
