package com.example.myfirstswplab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int i = 1;
    int j = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = (Button)findViewById(R.id.button2);
        Button btn2 = (Button)findViewById(R.id.button3);
        final TextView text = (TextView)findViewById(R.id.textView);
        final ImageView img = (ImageView)findViewById(R.id.imageView);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i = 1 - i;
                if (i == 0) {
                    text.setText("2016311209");
                }
                if (i == 1) {
                    text.setText("Gyeonghyeon Cho");
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j = j + 1;
                if (j == 3) {
                    j = 0;
                }
                if (j == 0) {
                    img.setImageResource(R.drawable.chicken);
                }
                if (j == 1) {
                    img.setImageResource(R.drawable.pizza);
                }
                if (j == 2) {
                    img.setImageResource(R.drawable.mokoko);
                }
            }
        });
    }
}