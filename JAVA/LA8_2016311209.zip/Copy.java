import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy {
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java Copy sourceFile targetFile");
			System.exit(0);
		}

		File fin = new File("C:\\Users\\khcho\\eclipse-workspace\\Week8\\" + args[0]);
		File fout = new File("C:\\Users\\khcho\\eclipse-workspace\\Week8\\" + args[1]);
		
		if (!fin.exists()) {
			System.out.println("Source file " + args[0] + " does not exist");
			System.exit(0);
		}

		if (fout.exists()) {
			System.out.println("Target file " + args[1] + " already exist");
			System.exit(0);
		}
		
		System.out.println(fin.length() + " bytes copied");
		
		FileInputStream fin2 = null;
		FileOutputStream fout2 = null;
		
		try {
			fin2 = new FileInputStream("C:\\Users\\khcho\\eclipse-workspace\\Week8\\" + args[0]);
			fout2 = new FileOutputStream("C:\\Users\\khcho\\eclipse-workspace\\Week8\\" + args[1]);
			byte[] buffer = new byte[1024];
			int count = 0;
			
			while ((count = fin2.read(buffer)) != -1)
				fout2.write(buffer, 0, count);
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}