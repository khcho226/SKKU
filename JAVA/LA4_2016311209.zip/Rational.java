package week5;
 
public class Rational extends Number implements Creator {
	
	private long numerator = 0;
	private long denominator = 1;
	
	public Rational() {
		this(0,1);
	}
	
	public Rational(long numerator, long denominator) {
		if (numerator == 0) {
			this.numerator = 0;
			this.denominator = denominator;
		}
		else {
			long gcd = gcd(numerator, denominator);
			this.numerator = ((denominator > 0) ? 1 : -1) * numerator / gcd;
			this.denominator = Math.abs(denominator) / gcd;
		}
	}
	
	private static long gcd(long n, long d) { 
		long a, b, remain, result;
		if (n < 0)
			n = -n;
		if (d < 0)
			d = -d;
		if (n > d) {
			a = n;
			b = d;
		}
		else {
			a = d;
			b = n;
		}		
		while (true) {
			if (a / b < 1) {
				result = 1;
				break;
			}
			remain = a % b;
			if (remain == 0) {
				result = b;
				break;
			}
			a = b;
			b = remain;
		}		
		return result;
	}
	
	public long getNumerator() {
		return numerator;
	}
	
	public long getDenominator() {
		return denominator;
	}
	
	public Rational add(Rational secondRational) {
		long n = numerator * secondRational.getDenominator() + denominator * secondRational.getNumerator();
		long d = denominator * secondRational.getDenominator();
		return new Rational(n, d);
	}
	
	public Rational subtract(Rational secondRational) {
		long n = numerator * secondRational.getDenominator() - denominator * secondRational.getNumerator();
		long d = denominator * secondRational.getDenominator();
		return new Rational(n, d);
	}
	
	public Rational multiply(Rational secondRational) {
		long n = numerator * secondRational.getNumerator();
		long d = denominator * secondRational.getDenominator();
		return new Rational(n, d);
	}
	
	public Rational divide(Rational secondRational) {
		long n = numerator * secondRational.getDenominator();
		long d = denominator * secondRational.getNumerator();
		return new Rational(n, d);
	}
	
	@Override
	public String toString() {
		String a;
		if (numerator == 0)
			a = "0";
		else {
			if (denominator == 1)
				a = String.valueOf(numerator);
			else
				a = String.valueOf(numerator) + "/" + String.valueOf(denominator);
		}
		return a;
	}
	
	@Override
	public boolean equals(Object other) {
		Rational a = (Rational)other;
		return (numerator == a.getNumerator() && denominator == a.getDenominator());
	}
	
	@Override
	public void CreatorOfThisClass() {
		System.out.println("Creataor of this class is Cho Gyeonghyeon");
	}

	@Override
	public int intValue() {
		double a = (double) numerator / (double) denominator; 
		int b = (int) a;
		return b;
	}

	@Override
	public long longValue() {
		double a = (double) numerator / (double) denominator; 
		long b = (long) a;
		return b;
	}

	@Override
	public float floatValue() {
		double a = (double) numerator / (double) denominator; 
		float b = (float) a;
		return b;
	}

	@Override
	public double doubleValue() {
		double a = (double) numerator / (double) denominator; 
		return a;		
	}
}