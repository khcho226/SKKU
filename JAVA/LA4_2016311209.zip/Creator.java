package week5;
 
public interface Creator {
	public abstract void CreatorOfThisClass();
}