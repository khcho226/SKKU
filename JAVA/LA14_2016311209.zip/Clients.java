import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

class Test extends Thread {
	public void run() {
		try {
			Socket soc = new Socket("localhost", 5000);
			DataInputStream read = new DataInputStream(soc.getInputStream());
			DataOutputStream write = new DataOutputStream(soc.getOutputStream());
			
			Scanner scan = new Scanner(System.in);
			String name = scan.nextLine();
			write.writeUTF(name);
			
			System.out.println("Requested file name : " + name);
			System.out.println(read.readUTF());

			read.close();
			write.close();
			soc.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

public class Clients {
	public static void main (String[] args) {
			new Test().run();
	}
}