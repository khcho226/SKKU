import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	static private DataInputStream read;
	static private DataOutputStream write;
	
	public static void main (String[] args) {
		ServerSocket ss = null;
		int id = 0;
		try {
			ss = new ServerSocket (5000);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("server is ready");

		while (true) {
			try {
				Socket soc = ss.accept ();
				read = new DataInputStream(soc.getInputStream());
				write = new DataOutputStream(soc.getOutputStream());

				try {
					while (true) {
						String name = read.readUTF();
						String name_fi = "";
						System.out.println("File Name : " + name);
						
						try {
							FileReader fr = new FileReader(name);
							BufferedReader br = new BufferedReader(fr);
							String temp;
							while ((temp = br.readLine()) != null)
								name_fi += temp + "\n";
							br.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						write.writeUTF(name_fi);
						write.flush();
					}
					
				} catch (EOFException e) {
					System.out.print("");
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}