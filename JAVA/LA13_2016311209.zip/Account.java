import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account {
	private static Lock lock = new ReentrantLock();
	private static Condition newWithdraw = lock.newCondition();
	private static Condition newDeposit = lock.newCondition();
	private int balance = 1;
	private int counter = 1;
	
	public int getBalance() {
		return balance;
	}
	
	public void withdraw(int amount) {
		lock.lock();
		
		try {
			while (counter == 1)
				newWithdraw.await();
			
			if (balance - amount < 0) {
				counter = 1;
				System.out.println("\t\t\tWait for a deposit");
			}
			
			else {
				balance = balance - amount;
				System.out.println("\t\t\tWithdraw " + amount + "\t\t" + balance);
			}
			
			newDeposit.signal();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void deposit(int amount) {
		lock.lock();
		
		try {
			while (counter == 0)
				newDeposit.await();
			
			counter = 0;
			balance = balance + amount;
			System.out.println("Deposit " + amount + "\t\t\t\t\t" + balance);
			newWithdraw.signal();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			lock.unlock();
		}
	}
}