package W4;

public class Custom_Int {
	int num;
	
	Custom_Int (int num) {
		this.num = num;
	}
	
	void Sum (int n) {
		num = num + n;
	}
	
	void Subtract (int n) {
		num = num - n;
	}
	
	void Multiply (int n) {
		num = num * n;
	}
	
	void Division (int n) {
		num = num / n;
	}
	
	Custom_Int get_GCD (Custom_Int b) {
		int a1, a2, qu, re;
		Custom_Int fi = new Custom_Int(0);
		if (num > b.num) {
			a1 = num;
			a2 = b.num;
		}
		else {
			a1 = b.num;
			a2 = num;
		}
		while (true) {
			if (a1 / a2 < 1) {
				fi.num = 1;
				break;
			}
			qu = a1 / a2;
			re = a1 % a2;
			if (re == 0) {
				fi.num = a2;
				break;
			}
			a1 = a2;
			a2 = re;
		}			
	return fi;
	}
}
