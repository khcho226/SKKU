package Janggi;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Board {
	static int turn = 1;
	static int origin = 1;
	static int now = 0;
	static int row = 0;
	static int col = 0;
	static int keyval = 0;
	static char type = ' ';
	static char color = ' ';
	static int over = 0;
	
	static BufferedReader buff;
	static String line = "";	
	static int rowin = 0;
	static int colin = 0;
	String sub2;
	
	static gameObject rR1 = new gameObject(0, 0, 'R', 'r', 'g');
	static gameObject rR2 = new gameObject(0, 8, 'R', 'r', 'g');
	static gameObject rN1 = new gameObject(0, 1, 'N', 'r', 'g');
	static gameObject rN2 = new gameObject(0, 7, 'N', 'r', 'g');
	static gameObject rE1 = new gameObject(0, 2, 'E', 'r', 'g');
	static gameObject rE2 = new gameObject(0, 6, 'E', 'r', 'g');
	static gameObject rG1 = new gameObject(0, 3, 'G', 'r', 'g');
	static gameObject rG2 = new gameObject(0, 5, 'G', 'r', 'g');
	static gameObject rK = new gameObject(1, 4, 'K', 'r', 'g');
	static gameObject rC1 = new gameObject(2, 1, 'C', 'r', 'g');
	static gameObject rC2 = new gameObject(2, 7, 'C', 'r', 'g');
	static gameObject rP1 = new gameObject(3, 0, 'P', 'r', 'g');
	static gameObject rP2 = new gameObject(3, 2, 'P', 'r', 'g');
	static gameObject rP3 = new gameObject(3, 4, 'P', 'r', 'g');
	static gameObject rP4 = new gameObject(3, 6, 'P', 'r', 'g');
	static gameObject rP5 = new gameObject(3, 8, 'P', 'r', 'g');
	
	static gameObject gR1 = new gameObject(9, 0, 'R', 'g', 'r');
	static gameObject gR2 = new gameObject(9, 8, 'R', 'g', 'r');
	static gameObject gN1 = new gameObject(9, 1, 'N', 'g', 'r');
	static gameObject gN2 = new gameObject(9, 7, 'N', 'g', 'r');
	static gameObject gE1 = new gameObject(9, 2, 'E', 'g', 'r');
	static gameObject gE2 = new gameObject(9, 6, 'E', 'g', 'r');
	static gameObject gG1 = new gameObject(9, 3, 'G', 'g', 'r');
	static gameObject gG2 = new gameObject(9, 5, 'G', 'g', 'r');
	static gameObject gK = new gameObject(8, 4, 'K', 'g', 'r');
	static gameObject gC1 = new gameObject(7, 1, 'C', 'g', 'r');
	static gameObject gC2 = new gameObject(7, 7, 'C', 'g', 'r');
	static gameObject gP1 = new gameObject(6, 0, 'P', 'g', 'r');
	static gameObject gP2 = new gameObject(6, 2, 'P', 'g', 'r');
	static gameObject gP3 = new gameObject(6, 4, 'P', 'g', 'r');
	static gameObject gP4 = new gameObject(6, 6, 'P', 'g', 'r');
	static gameObject gP5 = new gameObject(6, 8, 'P', 'g', 'r');
	
	static HashMap<Integer, gameObject> alive = new HashMap<Integer, gameObject>() {{
		put(1, rR1);
		put(2, rR2);
		put(3, rN1);
		put(4, rN2);
		put(5, rE1);
		put(6, rE2);
		put(7, rG1);
		put(8, rG2);
		put(9, rK);
		put(10, rC1);
		put(11, rC2);
		put(12, rP1);
		put(13, rP2);
		put(14, rP3);
		put(15, rP4);
		put(16, rP5);
		put(17, gR1);
		put(18, gR2);
		put(19, gN1);
		put(20, gN2);
		put(21, gE1);
		put(22, gE2);
		put(23, gG1);
		put(24, gG2);
		put(25, gK);
		put(26, gC1);
		put(27, gC2);
		put(28, gP1);
		put(29, gP2);
		put(30, gP3);
		put(31, gP4);
		put(32, gP5);
	}};
	
	static int[][] object = {{2, 2, 2, 2, 0, 2, 2, 2, 2}, {0, 0, 0, 0, 2, 0, 0, 0, 0},
		{0, 2, 0, 0, 0, 0, 0, 2, 0}, {2, 0, 2, 0, 2, 0, 2, 0, 2}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 0, 1, 0, 1, 0, 1, 0, 1}, {0, 1, 0, 0, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, {1, 1, 1, 1, 0, 1, 1, 1, 1}};
	
	Board(boolean withFile) {
		if (withFile) {
			try {
				File read = new File(".\\Input.txt");
				FileReader reader = new FileReader(read);
				buff = new BufferedReader(reader);
			} catch (FileNotFoundException e) {
			} catch (IOException e)  {
				System.out.println(e);			
			}
			
			try {
				File write = new File(".\\Output.txt");
				BufferedWriter buff2 = new BufferedWriter(new FileWriter(write));
				if (write.isFile() && write.canWrite()) {
					buff2.write("Game with file? [Y/N]");
					buff2.newLine();
					buff2.write("Y");
					buff2.newLine();
					buff2.close();
				}
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}

	public boolean isFinish(boolean withFile) {
		if (over == 1)
			return true;
		
		if (alive.containsKey(9) == false) {
			System.out.println("Green wins");
			
			if (withFile) {
				FileWriter fw;
				try {
					fw = new FileWriter(".\\Output.txt", true);
					fw.write("Green wins\r\n");
					fw.close();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return true;
		}
		
		if (alive.containsKey(25) == false) {
			System.out.println("Red wins");
			
			if (withFile) {
				FileWriter fw;
				try {
					fw = new FileWriter(".\\Output.txt", true);
					fw.write("Red wins\r\n");
					fw.close();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return true;
		}

		else
			return false;
	}
	
	public void selectObject(boolean withFile) {
		int count = 0;
		int count2 = 0;
		int count3 = 0;
		int count4 = 0;
		int count5 = 0;

		Scanner scan2 = new Scanner(System.in);
		String input3 = new String("");
		
		while (true) {
			if (withFile) {
				if (withFile) {
					FileWriter fw;
					try {
						fw = new FileWriter(".\\Output.txt", true);
						fw.write("Select piece: ");
						fw.close();
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
				try {
					line = buff.readLine();
					String sub1 = line.substring(0, 1);
					
					if (!sub1.equals("F")) {
						sub2 = line.substring(1, 2);
						System.out.println("Select piece: " + sub1 + sub2);
					}
					
					else
						System.out.println("Select piece: F");
					
					if (sub1.equals("F")) {
						over = 1;
						if (withFile) {
							FileWriter fw;
							try {
								fw = new FileWriter(".\\Output.txt", true);
								fw.write("F\r\n");
								fw.close();
								
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						break;
					}
					
					if (sub1.equals("a"))
						col = 0;
					if (sub1.equals("b"))
						col = 1;
					if (sub1.equals("c"))
						col = 2;
					if (sub1.equals("d"))
						col = 3;
					if (sub1.equals("e"))
						col = 4;
					if (sub1.equals("f"))
						col = 5;
					if (sub1.equals("g"))
						col = 6;
					if (sub1.equals("h"))
						col = 7;
					if (sub1.equals("i"))
						col = 8;
					
					if (sub2.equals("9"))
						row = 0;
					if (sub2.equals("8"))
						row = 1;
					if (sub2.equals("7"))
						row = 2;
					if (sub2.equals("6"))
						row = 3;
					if (sub2.equals("5"))
						row = 4;
					if (sub2.equals("4"))
						row = 5;
					if (sub2.equals("3"))
						row = 6;
					if (sub2.equals("2"))
						row = 7;
					if (sub2.equals("1"))
						row = 8;
					if (sub2.equals("0"))
						row = 9;
					
					if (withFile) {
						FileWriter fw;
						try {
							fw = new FileWriter(".\\Output.txt", true);
							fw.write(sub1 + sub2 + "\r\n");
							fw.close();
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				} catch (FileNotFoundException e) {
				} catch (IOException e)  {
					System.out.println(e);			
				}
			}
			
			if (!withFile) {
				System.out.print("Select piece: ");
				
				input3 = scan2.nextLine();
				String[] input2 = input3.split("");
				
				if (input2[0].equals("F")) {
					over = 1;
					break;
				}
				
				if (input2[0].equals("a"))
					col = 0;
				if (input2[0].equals("b"))
					col = 1;
				if (input2[0].equals("c"))
					col = 2;
				if (input2[0].equals("d"))
					col = 3;
				if (input2[0].equals("e"))
					col = 4;
				if (input2[0].equals("f"))
					col = 5;
				if (input2[0].equals("g"))
					col = 6;
				if (input2[0].equals("h"))
					col = 7;
				if (input2[0].equals("i"))
					col = 8;
				
				if (input2[1].equals("9"))
					row = 0;
				if (input2[1].equals("8"))
					row = 1;
				if (input2[1].equals("7"))
					row = 2;
				if (input2[1].equals("6"))
					row = 3;
				if (input2[1].equals("5"))
					row = 4;
				if (input2[1].equals("4"))
					row = 5;
				if (input2[1].equals("3"))
					row = 6;
				if (input2[1].equals("2"))
					row = 7;
				if (input2[1].equals("1"))
					row = 8;
				if (input2[1].equals("0"))
					row = 9;
			}
			
			count = 0;
			count2 = 0;
			count3 = 0;
			count4 = 0;
			count5 = 0;
			
			Iterator<Entry<Integer, gameObject>> entries = alive.entrySet().iterator();
			
			while (entries.hasNext()) {
				Map.Entry<Integer, gameObject> entry = entries.next();
				if (entry.getValue().getX() == row) {
					if (entry.getValue().getY() == col) {
						count = 1;
						if (turn == 1) {
							if (entry.getValue().getColor() == 'g') {
								turn = 2;
								origin = 1;
								count2 = 1;
								type = entry.getValue().getType();
								color = entry.getValue().getColor();
								keyval = entry.getKey();
								break;
							}
							else
								count4 = 1;
						}
						else {
							if (entry.getValue().getColor() == 'g')
								count4 = 1;
							else {
								turn = 1;
								origin = 2;
								count2 = 1;
								type = entry.getValue().getType();
								color = entry.getValue().getColor();
								keyval = entry.getKey();
								break;
							}
						}
					}
				}
			}
			
			if (turn == 1)
				now = 2;
			if (turn == 2)
				now = 1;
			
			if (type == 'P') {
				if (row > 0) {
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn) {
						if (turn == 2)
							object[row - 1][col] = 3;
					}
				}
				if (row < 9) {
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn) {
						if (turn == 1)
							object[row + 1][col] = 3;
					}
				}
				if (col > 0) {
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
				}
				if (col < 8) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
				}
			}
			
			if (type == 'K' || type == 'G') {
				if ((row == 0 && col == 3) || (row == 7 && col == 3)) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col + 1] == 0 || object[row + 1][col + 1] == turn)
						object[row + 1][col + 1] = 3;
				}
				if ((row == 0 && col == 4) || (row == 7 && col == 4)) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col + 1] == 0 || object[row + 1][col + 1] == turn)
						object[row + 1][col + 1] = 3;
					if (object[row + 1][col - 1] == 0 || object[row + 1][col - 1] == turn)
						object[row + 1][col - 1] = 3;
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
				}
				if ((row == 0 && col == 5) || (row == 7 && col == 5)) {
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col - 1] == 0 || object[row + 1][col - 1] == turn)
						object[row + 1][col - 1] = 3;
				}
				if ((row == 1 && col == 3) || (row == 8 && col == 3)) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col + 1] == 0 || object[row + 1][col + 1] == turn)
						object[row + 1][col + 1] = 3;
					if (object[row - 1][col + 1] == 0 || object[row - 1][col + 1] == turn)
						object[row - 1][col + 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
				}
				if ((row == 1 && col == 4) || (row == 8 && col == 4)) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col + 1] == 0 || object[row + 1][col + 1] == turn)
						object[row + 1][col + 1] = 3;
					if (object[row - 1][col + 1] == 0 || object[row - 1][col + 1] == turn)
						object[row - 1][col + 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
					if (object[row - 1][col - 1] == 0 || object[row - 1][col - 1] == turn)
						object[row - 1][col - 1] = 3;
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
					if (object[row + 1][col - 1] == 0 || object[row + 1][col - 1] == turn)
						object[row + 1][col - 1] = 3;
				}
				if ((row == 1 && col == 5) || (row == 8 && col == 5)) {
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
					if (object[row + 1][col] == 0 || object[row + 1][col] == turn)
						object[row + 1][col] = 3;
					if (object[row + 1][col - 1] == 0 || object[row + 1][col - 1] == turn)
						object[row + 1][col - 1] = 3;
					if (object[row - 1][col - 1] == 0 || object[row - 1][col - 1] == turn)
						object[row - 1][col - 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
				}
				if ((row == 2 && col == 3) || (row == 9 && col == 3)) {
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
					if (object[row - 1][col + 1] == 0 || object[row - 1][col + 1] == turn)
						object[row - 1][col + 1] = 3;
				}
				if ((row == 2 && col == 4) || (row == 9 && col == 4)) {
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
					if (object[row - 1][col - 1] == 0 || object[row - 1][col - 1] == turn)
						object[row - 1][col - 1] = 3;
					if (object[row - 1][col + 1] == 0 || object[row - 1][col + 1] == turn)
						object[row - 1][col + 1] = 3;
					if (object[row][col + 1] == 0 || object[row][col + 1] == turn)
						object[row][col + 1] = 3;
				}
				if ((row == 2 && col == 5) || (row == 9 && col == 5)) {
					if (object[row][col - 1] == 0 || object[row][col - 1] == turn)
						object[row][col - 1] = 3;
					if (object[row - 1][col] == 0 || object[row - 1][col] == turn)
						object[row - 1][col] = 3;
					if (object[row - 1][col - 1] == 0 || object[row - 1][col - 1] == turn)
						object[row - 1][col - 1] = 3;
				}
			}
			
			if (type == 'R') {
				for (int i = row + 1; i < 10; i++) {
					if (object[i][col] == now)
						break;
					if (object[i][col] == turn) {
						object[i][col] = 3;
						break;
					}
					object[i][col] = 3;
				}
				for (int i = row - 1; i > -1; i--) {
					if (object[i][col] == now)
						break;
					if (object[i][col] == turn) {
						object[i][col] = 3;;
						break;
					}
					object[i][col] = 3;;
				}
				for (int i = col + 1; i < 9; i++) {
					if (object[row][i] == now)
						break;
					if (object[row][i] == turn) {
						object[row][i] = 3;
						break;
					}
					object[row][i] = 3;
				}
				for (int i = col - 1; i > -1; i--) {
					if (object[row][i] == now)
						break;
					if (object[row][i] == turn) {
						object[row][i] = 3;
						break;
					}
					object[row][i] = 3;
				}
			}
			
			if (type == 'N') {
				if (row >= 2 && object[row - 1][col] == 0) {
					if (col >= 1) {
						if (object[row - 2][col - 1] == 0 || object[row - 2][col - 1] == turn)
							object[row - 2][col - 1] = 3;
					}
					if (col <= 7) {
						if (object[row - 2][col + 1] == 0 || object[row - 2][col + 1] == turn)
							object[row - 2][col + 1] = 3;
					}
				}
				if (row <= 8 && object[row + 1][col] == 0) {
					if (col >= 1) {
						if (object[row + 2][col - 1] == 0 || object[row + 2][col - 1] == turn)
							object[row + 2][col - 1] = 3;
					}
					if (col <= 7) {
						if (object[row + 2][col + 1] == 0 || object[row + 2][col + 1] == turn)
							object[row + 2][col + 1] = 3;
					}
				}
				if (col >= 2 && object[row][col - 1] == 0) {
					if (row >= 1) {
						if (object[row - 1][col - 2] == 0 || object[row - 1][col - 2] == turn)
							object[row - 1][col - 2] = 3;
					}
					if (row <= 8) {
						if (object[row + 1][col - 2] == 0 || object[row + 1][col - 2] == turn)
							object[row + 1][col - 2] = 3;
					}
				}
				if (col <= 7 && object[row][col + 1] == 0) {
					if (row >= 1) {
						if (object[row - 1][col + 2] == 0 || object[row - 1][col + 2] == turn)
							object[row - 1][col + 2] = 3;
					}
					if (row <= 8) {
						if (object[row + 1][col + 2] == 0 || object[row + 1][col + 2] == turn)
							object[row + 1][col + 2] = 3;
					}
				}
			}
			
			if (type == 'E') {
				if (row >= 3 && object[row - 1][col] == 0) {
					if (col >= 2 && object[row - 2][col - 1] == 0) {
						if (object[row - 3][col - 2] == 0 || object[row - 3][col - 2] == turn)
							object[row - 3][col - 2] = 3;
					}
					if (col <= 6 && object[row - 2][col + 1] == 0) {
						if (object[row - 3][col + 2] == 0 || object[row - 3][col + 2] == turn)
							object[row - 3][col + 2] = 3;
					}
				}
				if (row <= 6 && object[row + 1][col] == 0) {
					if (col >= 2 && object[row + 2][col - 1] == 0) {
						if (object[row + 3][col - 2] == 0 || object[row + 3][col - 2] == turn)
							object[row + 3][col - 2] = 3;
					}
					if (col <= 6 && object[row + 2][col + 1] == 0) {
						if (object[row + 3][col + 2] == 0 || object[row + 3][col + 2] == turn)
							object[row + 3][col + 2] = 3;
					}
				}
				if (col >= 3 && object[row][col - 1] == 0) {
					if (row >= 2 && object[row - 1][col - 2] == 0) {
						if (object[row - 2][col - 3] == 0 || object[row - 2][col - 3] == turn)
							object[row - 2][col - 3] = 3;
					}
					if (row <= 7 && object[row + 1][col - 2] == 0) {
						if (object[row + 2][col - 3] == 0 || object[row + 2][col - 3] == turn)
							object[row + 2][col - 3] = 3;
					}
				}
				if (col <= 5 && object[row][col + 1] == 0) {
					if (row >= 2 && object[row - 1][col + 2] == 0) {
						if (object[row - 2][col + 3] == 0 || object[row - 2][col + 3] == turn)
							object[row - 2][col + 3] = 3;
					}
					if (row <= 7 && object[row + 1][col + 2] == 0) {
						if (object[row + 2][col + 3] == 0 || object[row + 2][col + 3] == turn)
							object[row + 2][col + 3] = 3;
					}
				}
			}
			
			if (type == 'C') {
				int countC = 0;
				char d = ' ';
				
				for (int i = row + 1; i < 10; i++) {
					if (countC == 1) {
						if (object[i][col] == 0)
							object[i][col] = 3;
						
						else if (object[i][col] == now)
							break;
						
						else {
							Iterator<Entry<Integer, gameObject>> entries2 = alive.entrySet().iterator();					
							while (entries2.hasNext()) {
								Map.Entry<Integer, gameObject> entry2 = entries2.next();
								if (entry2.getValue().getX() == i) {
									if (entry2.getValue().getY() == col) {
										d = entry2.getValue().getType();
										break;
									}
								}
							}
							
							if (d == 'C')
								break;
							
							else {
								object[i][col] = 3;
								break;
							}
						}
					}
					
					if ((object[i][col] == 1 || object[i][col] == 2) && countC == 0) {
						Iterator<Entry<Integer, gameObject>> entries3 = alive.entrySet().iterator();					
						while (entries3.hasNext()) {
							Map.Entry<Integer, gameObject> entry3 = entries3.next();
							if (entry3.getValue().getX() == i) {
								if (entry3.getValue().getY() == col) {
									d = entry3.getValue().getType();
									break;
								}
							}
						}
						
						if (d != 'C')
							countC = 1;
						
						else
							break;
					}
				}
				
				countC = 0;
				for (int i = row - 1; i > -1; i--) {
					if (countC == 1) {
						if (object[i][col] == 0)
							object[i][col] = 3;
						
						else if (object[i][col] == now)
							break;
						
						else {
							Iterator<Entry<Integer, gameObject>> entries4 = alive.entrySet().iterator();					
							while (entries4.hasNext()) {
								Map.Entry<Integer, gameObject> entry4 = entries4.next();
								if (entry4.getValue().getX() == i) {
									if (entry4.getValue().getY() == col) {
										d = entry4.getValue().getType();
										break;
									}
								}
							}
							
							if (d == 'C')
								break;
							
							else {
								object[i][col] = 3;
								break;
							}
						}
					}
					
					if ((object[i][col] == 1 || object[i][col] == 2) && countC == 0) {
						Iterator<Entry<Integer, gameObject>> entries5 = alive.entrySet().iterator();					
						while (entries5.hasNext()) {
							Map.Entry<Integer, gameObject> entry5 = entries5.next();
							if (entry5.getValue().getX() == i) {
								if (entry5.getValue().getY() == col) {
									d = entry5.getValue().getType();
									break;
								}
							}
						}
						
						if (d != 'C')
							countC = 1;
						
						else
							break;
					}
				}
				
				countC = 0;
				for (int i = col + 1; i < 9; i++) {
					if (countC == 1) {
						if (object[row][i] == 0)
							object[row][i] = 3;
						
						else if (object[row][i] == now)
							break;
						
						else {
							Iterator<Entry<Integer, gameObject>> entries6 = alive.entrySet().iterator();					
							while (entries6.hasNext()) {
								Map.Entry<Integer, gameObject> entry6 = entries6.next();
								if (entry6.getValue().getX() == row) {
									if (entry6.getValue().getY() == i) {
										d = entry6.getValue().getType();
										break;
									}
								}
							}
							
							if (d == 'C')
								break;
							
							else {
								object[row][i] = 3;
								break;
							}
						}
					}
					
					if ((object[row][i] == 1 || object[row][i] == 2) && countC == 0) {
						Iterator<Entry<Integer, gameObject>> entries7 = alive.entrySet().iterator();					
						while (entries7.hasNext()) {
							Map.Entry<Integer, gameObject> entry7 = entries7.next();
							if (entry7.getValue().getX() == row) {
								if (entry7.getValue().getY() == i) {
									d = entry7.getValue().getType();
									break;
								}
							}
						}
						
						if (d != 'C')
							countC = 1;
						
						else
							break;
					}
				}
				
				countC = 0;
				for (int i = col - 1; i > -1; i--) {
					if (countC == 1) {
						if (object[row][i] == 0)
							object[row][i] = 3;
						
						else if (object[row][i] == now)
							break;
						
						else {
							Iterator<Entry<Integer, gameObject>> entries8 = alive.entrySet().iterator();					
							while (entries8.hasNext()) {
								Map.Entry<Integer, gameObject> entry8 = entries8.next();
								if (entry8.getValue().getX() == row) {
									if (entry8.getValue().getY() == i) {
										d = entry8.getValue().getType();
										break;
									}
								}
							}
							
							if (d == 'C')
								break;
							
							else {
								object[row][i] = 3;
								break;
							}
						}
					}
					
					if ((object[row][i] == 1 || object[row][i] == 2) && countC == 0) {
						Iterator<Entry<Integer, gameObject>> entries9 = alive.entrySet().iterator();					
						while (entries9.hasNext()) {
							Map.Entry<Integer, gameObject> entry9 = entries9.next();
							if (entry9.getValue().getX() == row) {
								if (entry9.getValue().getY() == i) {
									d = entry9.getValue().getType();
									break;
								}
							}
						}
						
						if (d != 'C')
							countC = 1;
						
						else
							break;
					}
				}
			}
			
			for (int i = 0; i < 10; i++) {
				for (int j = 0; j < 9; j++) {
					if (object[i][j] == 3)
						count3 = count3 + 1;
				}
			}
			
			if (count == 0)
				count5 = 1;
			if (count2 == 1 && count3 != 0)
				break;
			if (count5 != 1) {
				if (count3 == 0 && count4 != 1) {
					turn = origin;
				}
			}
			
			for (int i = 0; i < 10; i++) {
				for (int j = 0; j < 9; j++) {
					if (object[i][j] == 3)
						object[i][j] = 0;
				}
			}
		}
		
		if (over != 1) {
			if (withFile) {
				rowin = row;
				colin = col;
			}
			
			String ANSI_RESET = "\033[0m";
			String ANSI_FG_BLACK = "\033[30m";
			String ANSI_FG_WHITE = "\033[37m";
			String ANSI_BG_BLACK = "\033[40m";
			String ANSI_BG_WHITE = "\033[47m";
			char a = ' ';
			char b = ' ';
			char c = ' ';
			
			System.out.println("   a  b  c  d  e  f  g  h  i");
			
			if (withFile) {
				FileWriter fw;
				try {
					fw = new FileWriter(".\\Output.txt", true);
					fw.write("   a  b  c  d  e  f  g  h  i\r\n");
					fw.close();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			for (int i = 0; i < 10; i++) {
				System.out.print(9 - i + " ");
				
				if (withFile) {
					FileWriter fw;
					try {
						fw = new FileWriter(".\\Output.txt", true);
						fw.write(9 - i + " ");
						fw.close();
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
				for (int j = 0; j < 9; j++) {
					a = ' ';
					b = ' ';
					c = ' ';
					Iterator<Entry<Integer, gameObject>> entries = alive.entrySet().iterator();
					
					while (entries.hasNext()) {
						Map.Entry<Integer, gameObject> entry = entries.next();
						if (entry.getValue().getX() == i) {
							if (entry.getValue().getY() == j) {
								a = entry.getValue().getColor();
								b = entry.getValue().getType();
								break;
							}
						}
					}
					
					if (object[i][j] == 3)
						c = '*';
			
					if ((i + j) % 2 == 1) {
						System.out.print(ANSI_BG_BLACK + ANSI_FG_WHITE
								+ a + b + c
								+ ANSI_RESET + ANSI_RESET);
						
						if (withFile) {
							FileWriter fw;
							try {
								fw = new FileWriter(".\\Output.txt", true);
								fw.write(ANSI_BG_BLACK + ANSI_FG_WHITE
										+ a + b + c
										+ ANSI_RESET + ANSI_RESET);
								fw.close();
								
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}				
					else {
						System.out.print(ANSI_BG_WHITE + ANSI_FG_BLACK
								+ a + b + c
								+ ANSI_RESET + ANSI_RESET);
						
						if (withFile) {
							FileWriter fw;
							try {
								fw = new FileWriter(".\\Output.txt", true);
								fw.write(ANSI_BG_WHITE + ANSI_FG_BLACK
										+ a + b + c
										+ ANSI_RESET + ANSI_RESET);
								fw.close();
								
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				
				System.out.print("\n");
				
				if (withFile) {
					FileWriter fw;
					try {
						fw = new FileWriter(".\\Output.txt", true);
						fw.write("\r\n");
						fw.close();
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public void moveObject(boolean withFile) {
		int row2 = 0;
		int col2 = 0;
		int keylose = 0;
		
		if (over != 1) {
			Scanner scan3 = new Scanner(System.in);
			String input4 = new String("");
			
			while (true) {
				if (withFile) {
					if (withFile) {
						FileWriter fw;
						try {
							fw = new FileWriter(".\\Output.txt", true);
							fw.write("Move piece: ");
							fw.close();
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					
					String sub1 = line.substring(4, 5);
					
					if (!sub1.equals("F")) {
						sub2 = line.substring(5, 6);
						System.out.println("Move piece: " + sub1 + sub2);
					}
					
					else
						System.out.println("Move piece: F");
					
					if (sub1.equals("F")) {
						over = 1;
						if (withFile) {
							FileWriter fw;
							try {
								fw = new FileWriter(".\\Output.txt", true);
								fw.write("F\r\n");
								fw.close();
								
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						break;
					}
					
					if (sub1.equals("a"))
						col2 = 0;
					if (sub1.equals("b"))
						col2 = 1;
					if (sub1.equals("c"))
						col2 = 2;
					if (sub1.equals("d"))
						col2 = 3;
					if (sub1.equals("e"))
						col2 = 4;
					if (sub1.equals("f"))
						col2 = 5;
					if (sub1.equals("g"))
						col2 = 6;
					if (sub1.equals("h"))
						col2 = 7;
					if (sub1.equals("i"))
						col2 = 8;
					
					if (sub2.equals("9"))
						row2 = 0;
					if (sub2.equals("8"))
						row2 = 1;
					if (sub2.equals("7"))
						row2 = 2;
					if (sub2.equals("6"))
						row2 = 3;
					if (sub2.equals("5"))
						row2 = 4;
					if (sub2.equals("4"))
						row2 = 5;
					if (sub2.equals("3"))
						row2 = 6;
					if (sub2.equals("2"))
						row2 = 7;
					if (sub2.equals("1"))
						row2 = 8;
					if (sub2.equals("0"))
						row2 = 9;
					
					if (withFile) {
						FileWriter fw;
						try {
							fw = new FileWriter(".\\Output.txt", true);
							fw.write(sub1 + sub2 + "\r\n");
							fw.close();
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					
					if (withFile) {
						
					}
				}
				
				if (!withFile) {
					System.out.print("Move piece: ");
					input4 = scan3.nextLine();
					String[] input5 = input4.split("");
					
					if (input5[0].equals("F")) {
						over = 1;
						break;
					}
					
					if (input5[0].equals("a"))
						col2 = 0;
					if (input5[0].equals("b"))
						col2 = 1;
					if (input5[0].equals("c"))
						col2 = 2;
					if (input5[0].equals("d"))
						col2 = 3;
					if (input5[0].equals("e"))
						col2 = 4;
					if (input5[0].equals("f"))
						col2 = 5;
					if (input5[0].equals("g"))
						col2 = 6;
					if (input5[0].equals("h"))
						col2 = 7;
					if (input5[0].equals("i"))
						col2 = 8;
				
					if (input5[1].equals("9"))
						row2 = 0;
					if (input5[1].equals("8"))
						row2 = 1;
					if (input5[1].equals("7"))
						row2 = 2;
					if (input5[1].equals("6"))
						row2 = 3;
					if (input5[1].equals("5"))
						row2 = 4;
					if (input5[1].equals("4"))
						row2 = 5;
					if (input5[1].equals("3"))
						row2 = 6;
					if (input5[1].equals("2"))
						row2 = 7;
					if (input5[1].equals("1"))
						row2 = 8;
					if (input5[1].equals("0"))
						row2 = 9;
				}
				
				Iterator<Entry<Integer, gameObject>> entries = alive.entrySet().iterator();
				
				while (entries.hasNext()) {
					Map.Entry<Integer, gameObject> entry = entries.next();
					if (entry.getValue().getX() == row2) {
						if (entry.getValue().getY() == col2) {
							keylose = entry.getKey();
							break;
						}
					}
				}
				
				if (keylose != 0)
					alive.remove(keylose);
				
				if (object[row2][col2] == 3) {
					object[row][col] = 0;
					gameObject move = new gameObject(row2, col2, type, color, 'x');
					alive.put(keyval, move);
					if (turn == 2)
						object[row2][col2] = 1;
					if (turn == 1)
						object[row2][col2] = 2;
					break;
				}
				
				if (withFile) {
					while (true) {
						int row3 = 0;
						int col3 = 0;
						
						try {
							line = buff.readLine();
							String sub1 = line.substring(0, 1);
							
							if (!sub1.equals("F"))
								sub2 = line.substring(1, 2);
				
							if (sub1.equals("F")) {
								over = 1;
								break;
							}
							
							if (sub1.equals("a"))
								col3 = 0;
							if (sub1.equals("b"))
								col3 = 1;
							if (sub1.equals("c"))
								col3 = 2;
							if (sub1.equals("d"))
								col3 = 3;
							if (sub1.equals("e"))
								col3 = 4;
							if (sub1.equals("f"))
								col3 = 5;
							if (sub1.equals("g"))
								col3 = 6;
							if (sub1.equals("h"))
								col3 = 7;
							if (sub1.equals("i"))
								col3 = 8;
							
							if (sub2.equals("9"))
								row3 = 0;
							if (sub2.equals("8"))
								row3 = 1;
							if (sub2.equals("7"))
								row3 = 2;
							if (sub2.equals("6"))
								row3 = 3;
							if (sub2.equals("5"))
								row3 = 4;
							if (sub2.equals("4"))
								row3 = 5;
							if (sub2.equals("3"))
								row3 = 6;
							if (sub2.equals("2"))
								row3 = 7;
							if (sub2.equals("1"))
								row3 = 8;
							if (sub2.equals("0"))
								row3 = 9;
							
							if (row3 == rowin && col3 == colin)
								break;
						} catch (FileNotFoundException e) {
						} catch (IOException e)  {
							System.out.println(e);			
						}
					}
					
					if (over == 1)
						break;
				}
			}
		}
		
		if (over != 1) {
			for (int i = 0; i < 10; i++) {
				for (int j = 0; j < 9; j++) {
					if (object[i][j] == 3)
						object[i][j] = 0;
				}
			}
		}
	}
	
	public void printBoard(boolean withFile) {
		String ANSI_RESET = "\033[0m";
		String ANSI_FG_BLACK = "\033[30m";
		String ANSI_FG_WHITE = "\033[37m";
		String ANSI_BG_BLACK = "\033[40m";
		String ANSI_BG_WHITE = "\033[47m";
		char a = ' ';
		char b = ' ';
		
		System.out.println("   a  b  c  d  e  f  g  h  i");
		
		if (withFile) {
			FileWriter fw;
			try {
				fw = new FileWriter(".\\Output.txt", true);
				fw.write("   a  b  c  d  e  f  g  h  i\r\n");
				fw.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		for (int i = 0; i < 10; i++) {
			System.out.print(9 - i + " ");
			
			if (withFile) {
				FileWriter fw;
				try {
					fw = new FileWriter(".\\Output.txt", true);
					fw.write(9 - i + " ");
					fw.close();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			for (int j = 0; j < 9; j++) {
				a = ' ';
				b = ' ';
				Iterator<Entry<Integer, gameObject>> entries = alive.entrySet().iterator();
				
				while (entries.hasNext()) {
					Map.Entry<Integer, gameObject> entry = entries.next();
					if (entry.getValue().getX() == i) {
						if (entry.getValue().getY() == j) {
							a = entry.getValue().getColor();
							b = entry.getValue().getType();
							break;
						}
					}
				}
				
				if ((i + j) % 2 == 1) {
					System.out.print(ANSI_BG_BLACK + ANSI_FG_WHITE
							+ a + b + " "
							+ ANSI_RESET + ANSI_RESET);
					
					if (withFile) {
						FileWriter fw;
						try {
							fw = new FileWriter(".\\Output.txt", true);
							fw.write(ANSI_BG_BLACK + ANSI_FG_WHITE
									+ a + b + " "
									+ ANSI_RESET + ANSI_RESET);
							fw.close();
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}				
				else {
					System.out.print(ANSI_BG_WHITE + ANSI_FG_BLACK
							+ a + b + " "
							+ ANSI_RESET + ANSI_RESET);
					
					if (withFile) {
						FileWriter fw;
						try {
							fw = new FileWriter(".\\Output.txt", true);
							fw.write(ANSI_BG_WHITE + ANSI_FG_BLACK
									+ a + b + " "
									+ ANSI_RESET + ANSI_RESET);
							fw.close();
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			}
			
			System.out.print("\n");
			
			if (withFile) {
				FileWriter fw;
				try {
					fw = new FileWriter(".\\Output.txt", true);
					fw.write("\r\n");
					fw.close();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}